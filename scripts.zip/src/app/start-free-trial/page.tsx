import { redirect } from "next/navigation";

export default function StartFreeTrialPage() {
  redirect("https://xplorebyte.com/start-free-trial");
}
