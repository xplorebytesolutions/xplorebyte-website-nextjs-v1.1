import { redirect } from "next/navigation";

export default function WhatsAppCrmForDoctorsRedirect() {
  redirect("/whatsapp-crm-for-clinics-and-doctors");
}
